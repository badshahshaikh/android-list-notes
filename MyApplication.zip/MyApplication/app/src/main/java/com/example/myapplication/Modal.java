package com.example.myapplication;

public class Modal {

    private String text;

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }

    public Modal(String text) {
        this.text = text;
    }
}
